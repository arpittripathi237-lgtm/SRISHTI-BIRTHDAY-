# Srishti Birthday Website

Open `index.html` in a browser to preview the website.

To publish it, upload the whole folder (keeping `index.html` and `photos/` together)
to a static website host such as GitHub Pages, Netlify, or Cloudflare Pages.
